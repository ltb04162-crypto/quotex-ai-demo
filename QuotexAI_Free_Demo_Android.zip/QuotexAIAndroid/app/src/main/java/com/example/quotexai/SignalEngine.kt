package com.example.quotexai

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Candle(val open: Double, val high: Double, val low: Double, val close: Double)
enum class Direction { CALL, PUT, WAIT }
data class Signal(val direction: Direction, val confidence: Int, val rsi: Double,
                  val emaFast: Double, val emaSlow: Double, val macd: Double,
                  val explanation: String)

object SignalEngine {
    // Educational indicator engine. Feed it real, timestamped OHLC candles from a
    // properly licensed market-data provider before treating results as live signals.
    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val alpha = 2.0 / (period + 1.0)
        return values.drop(1).fold(values.first()) { acc, v -> alpha * v + (1-alpha) * acc }
    }

    private fun rsi(values: List<Double>, period: Int = 14): Double {
        if (values.size <= period) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gains = changes.filter { it > 0 }.sum() / period
        val losses = -changes.filter { it < 0 }.sum() / period
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun analyze(candles: List<Candle>): Signal {
        if (candles.size < 40) return Signal(Direction.WAIT, 0, 50.0, 0.0, 0.0, 0.0,
            "At least 40 completed candles are required.")
        val closes = candles.map { it.close }
        val fast = ema(closes.takeLast(40), 9)
        val slow = ema(closes.takeLast(40), 21)
        val macd = ema(closes, 12) - ema(closes, 26)
        val rsi = rsi(closes)
        val last = candles.last()
        val range = max(last.high - last.low, 1e-9)
        val bodyRatio = abs(last.close - last.open) / range

        var score = 0
        if (fast > slow) score += 1 else if (fast < slow) score -= 1
        if (macd > 0) score += 1 else if (macd < 0) score -= 1
        if (rsi in 50.0..68.0) score += 1
        if (rsi in 32.0..50.0) score -= 1
        if (last.close > last.open && bodyRatio > 0.45) score += 1
        if (last.close < last.open && bodyRatio > 0.45) score -= 1

        val direction = when {
            score >= 3 && rsi < 70 -> Direction.CALL
            score <= -3 && rsi > 30 -> Direction.PUT
            else -> Direction.WAIT
        }
        val confidence = min(90, 50 + abs(score) * 8 + (bodyRatio * 5).toInt())
        val note = when (direction) {
            Direction.CALL -> "Bullish EMA/MACD alignment. Confirmation is not guaranteed."
            Direction.PUT -> "Bearish EMA/MACD alignment. Confirmation is not guaranteed."
            Direction.WAIT -> "Indicators are mixed or momentum is weak. Wait."
        }
        return Signal(direction, if (direction == Direction.WAIT) min(confidence, 59) else confidence,
            rsi, fast, slow, macd, note)
    }
}
