package com.example.quotexai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class MarketSnapshot(
    val candles: List<Candle>,
    val latestClose: Double,
    val latestTimestamp: String
)

object MarketData {
    // Twelve Data REST time_series. API key is entered by the user and held in memory only.
    fun fetchOneMinuteCandles(symbol: String, apiKey: String): MarketSnapshot {
        require(apiKey.isNotBlank()) { "Enter your Twelve Data API key." }
        val querySymbol = URLEncoder.encode(symbol, "UTF-8")
        val queryKey = URLEncoder.encode(apiKey.trim(), "UTF-8")
        val url = URL("https://api.twelvedata.com/time_series?symbol=$querySymbol&interval=1min&outputsize=100&apikey=$queryKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
        }
        try {
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            if (json.optString("status") == "error") {
                throw IllegalStateException(json.optString("message", "Market data provider error"))
            }
            val values = json.optJSONArray("values")
                ?: throw IllegalStateException("No candles returned. Check API key, pair and plan.")
            val candles = (0 until values.length()).map { i ->
                val row = values.getJSONObject(i)
                Candle(
                    open = row.getString("open").toDouble(),
                    high = row.getString("high").toDouble(),
                    low = row.getString("low").toDouble(),
                    close = row.getString("close").toDouble()
                )
            }.reversed()
            if (candles.size < 40) throw IllegalStateException("Fewer than 40 candles returned.")
            val newest = values.getJSONObject(0)
            MarketSnapshot(candles, newest.getString("close").toDouble(), newest.optString("datetime", "time unavailable"))
        } finally {
            connection.disconnect()
        }
    }
}
