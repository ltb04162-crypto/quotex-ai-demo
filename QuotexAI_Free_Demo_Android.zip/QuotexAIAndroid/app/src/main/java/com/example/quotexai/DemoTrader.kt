package com.example.quotexai

data class PaperTrade(
    val symbol: String,
    val direction: Direction,
    val entryPrice: Double,
    val stake: Double,
    val openedAtMillis: Long,
    val signalScore: Int
)

data class TradeRecord(
    val symbol: String,
    val direction: Direction,
    val entryPrice: Double,
    val exitPrice: Double,
    val stake: Double,
    val profitLoss: Double,
    val result: String
)

class DemoTrader(
    startingBalance: Double = 10_000.0,
    private val riskFraction: Double = 0.01,
    private val assumedPayout: Double = 0.80,
    private val expiryMillis: Long = 5 * 60 * 1000L
) {
    var balance: Double = startingBalance
        private set
    private val openTrades = mutableMapOf<String, PaperTrade>()
    val history = mutableListOf<TradeRecord>()

    fun openIfSignal(symbol: String, signal: Signal, price: Double, now: Long): PaperTrade? {
        if (signal.direction == Direction.WAIT || openTrades.containsKey(symbol)) return null
        val stake = (balance * riskFraction).coerceAtMost(balance)
        if (stake <= 0.0) return null
        val trade = PaperTrade(symbol, signal.direction, price, stake, now, signal.confidence)
        openTrades[symbol] = trade
        balance -= stake // reserve stake while trade is open
        return trade
    }

    fun settleIfDue(symbol: String, currentPrice: Double, now: Long): TradeRecord? {
        val trade = openTrades[symbol] ?: return null
        if (now - trade.openedAtMillis < expiryMillis) return null
        val won = when (trade.direction) {
            Direction.CALL -> currentPrice > trade.entryPrice
            Direction.PUT -> currentPrice < trade.entryPrice
            Direction.WAIT -> false
        }
        val tie = currentPrice == trade.entryPrice
        val pnl = when {
            tie -> 0.0
            won -> trade.stake * assumedPayout
            else -> -trade.stake
        }
        // Stake was reserved on entry; return stake plus profit if won, stake on tie.
        balance += when {
            tie -> trade.stake
            won -> trade.stake + pnl
            else -> 0.0
        }
        val record = TradeRecord(
            trade.symbol, trade.direction, trade.entryPrice, currentPrice,
            trade.stake, pnl, when { tie -> "DRAW"; won -> "WIN"; else -> "LOSS" }
        )
        history.add(0, record)
        openTrades.remove(symbol)
        return record
    }

    fun openTrade(symbol: String): PaperTrade? = openTrades[symbol]
    fun openCount(): Int = openTrades.size
}
