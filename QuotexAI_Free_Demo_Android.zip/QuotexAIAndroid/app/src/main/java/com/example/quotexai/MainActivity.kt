package com.example.quotexai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DemoScreen() } }
    }
}

@Composable
fun DemoScreen() {
    val symbols = listOf("EUR/USD", "GBP/USD")
    var apiKey by remember { mutableStateOf("") }
    var connected by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Add your free-plan API key, then connect.") }
    var lastUpdated by remember { mutableStateOf("Not updated yet") }
    var snapshots by remember { mutableStateOf(mapOf<String, MarketSnapshot>()) }
    var signals by remember { mutableStateOf(mapOf<String, Signal>()) }
    var historyVersion by remember { mutableIntStateOf(0) }
    val trader = remember { DemoTrader() }
    val scope = rememberCoroutineScope()
    val history = trader.history

    suspend fun updateMarkets() {
        if (apiKey.isBlank()) return
        loading = true
        try {
            val fresh = withContext(Dispatchers.IO) {
                symbols.associateWith { symbol -> MarketData.fetchOneMinuteCandles(symbol, apiKey) }
            }
            val now = System.currentTimeMillis()
            val newSignals = fresh.mapValues { (_, snap) -> SignalEngine.analyze(snap.value.candles) }
            // First settle trades opened at least five minutes ago, then consider new signals.
            fresh.forEach { (symbol, snap) ->
                trader.settleIfDue(symbol, snap.latestClose, now)
            }
            if (running) {
                fresh.forEach { (symbol, snap) ->
                    trader.openIfSignal(symbol, newSignals.getValue(symbol), snap.latestClose, now)
                }
            }
            snapshots = fresh
            signals = newSignals
            historyVersion++
            connected = true
            lastUpdated = "Latest candle: " + fresh.values.first().latestTimestamp
            status = if (running) "LIVE DATA CONNECTED · DEMO AUTO-TRADING ON"
                     else "LIVE DATA CONNECTED · DEMO AUTO-TRADING OFF"
        } catch (e: Exception) {
            connected = false
            status = "Feed error: ${e.message ?: "Connection failed"}"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(running, connected, apiKey) {
        if (running && connected && apiKey.isNotBlank()) {
            while (isActive) {
                delay(5 * 60 * 1000L)
                updateMarkets()
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("QUOTEX AI · FREE DEMO", style = MaterialTheme.typography.headlineSmall)
            Text("2 major FX pairs · 5-minute paper trades")
            Text(status, color = if (connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            Text(lastUpdated, style = MaterialTheme.typography.bodySmall)
        }
        item {
            OutlinedTextField(
                value = apiKey, onValueChange = { apiKey = it; connected = false; running = false },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                label = { Text("Twelve Data API key") },
                placeholder = { Text("Enter key here — do not share it") }
            )
            Text("Key stays in app memory only and is cleared when the app process closes.",
                style = MaterialTheme.typography.bodySmall)
        }
        item {
            Button(
                onClick = { scope.launch { updateMarkets() } },
                enabled = !loading && apiKey.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (loading) "Fetching live candles…" else "Connect / Refresh live data") }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("DEMO ACCOUNT", style = MaterialTheme.typography.titleMedium)
                    Text("Available balance: " + money(trader.balance))
                    Text("Starting balance: ₹10,000 · Risk per trade: 1% of available balance")
                    Text("Initial stake: ₹100 · 5-minute expiry")
                    Text("Open demo trades: ${trader.openCount()}")
                    Text("Illustrative payout assumption: 80% on a win (not Quotex's live payout).",
                        style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Switch(checked = running, onCheckedChange = {
                            running = it
                            if (it && connected) scope.launch { updateMarkets() }
                        }, enabled = connected && !loading)
                        Spacer(Modifier.width(8.dp))
                        Text(if (running) "AUTO DEMO ON" else "AUTO DEMO OFF")
                    }
                    Text("Automatic paper trading runs only while this app stays open and connected.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("LIVE SIGNALS", style = MaterialTheme.typography.titleMedium) }
        items(symbols.size) { idx ->
            val symbol = symbols[idx]
            val snap = snapshots[symbol]
            val sig = signals[symbol]
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(symbol, style = MaterialTheme.typography.titleMedium)
                    Text(sig?.direction?.name ?: "WAITING", style = MaterialTheme.typography.headlineMedium)
                    Text("Latest close: ${snap?.latestClose?.let { "%.5f".format(Locale.US, it) } ?: "—"}")
                    Text("RSI ${sig?.rsi?.let { "%.1f".format(Locale.US, it) } ?: "—"} · Score ${sig?.confidence ?: 0}/100")
                    Text(sig?.explanation ?: "Connect to load data.")
                    val open = trader.openTrade(symbol)
                    if (open != null) Text("Open paper trade: ${open.direction} · stake ${money(open.stake)} · entry ${open.entryPrice}")
                }
            }
        }
        item {
            Text("PAPER TRADE HISTORY", style = MaterialTheme.typography.titleMedium)
            Text("Settled trades: ${history.size} · Open trades: ${trader.openCount()}")
        }
        items(history.take(30).toList()) { record ->
            Text("${record.symbol} ${record.direction} · ${record.result} · P/L ${money(record.profitLoss)}")
        }
        item {
            Text(
                "Risk notice: This is an educational paper-trading simulator, not Quotex integration. External FX prices may differ from Quotex quotes. A 1-minute candle feed refreshed every five minutes can be delayed and is not a guaranteed execution price. The 80% payout is an illustrative assumption. No real orders are sent and no profit is guaranteed.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun money(value: Double): String = "₹" + String.format(Locale.US, "%.2f", value)
