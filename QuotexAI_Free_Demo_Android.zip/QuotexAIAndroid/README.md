# Quotex AI — Free live-data demo trading Android starter

**This is Android Studio source code, not a compiled APK.** It is configured for:
- EUR/USD and GBP/USD only
- Twelve Data 1-minute OHLC candles
- EMA 9/21, RSI 14 and MACD signal heuristics
- ₹10,000 starting paper balance
- 1% stake of currently available demo balance per trade (initially ₹100)
- 5-minute paper-trade expiry
- automatic demo entries and settlements while app is open
- illustrative 80% payout assumption (editable in DemoTrader.kt)

## Set up
1. Create/check your Twelve Data account and verify your free plan's current credits, forex coverage, data delay and display/use licensing.
2. Open this folder in Android Studio with JDK 17.
3. Sync Gradle and build: Build > Build APK(s).
4. Install the debug APK on your Android phone.
5. Enter your API key inside the app, tap Connect / Refresh, then enable AUTO DEMO.

## Important
- API key is held in memory only. It is not persisted, but anyone who extracts it from a distributed client could still misuse it; do not publish/share this APK with your personal key.
- Refresh interval is five minutes for the two symbols. A failed request, app suspension, or market closure pauses reliable simulation.
- Trades are settled against the next fetched external FX close after at least five minutes, not against Quotex execution prices.
- The 80% payout is a sample assumption, not a live Quotex payout.
- This does not log in to Quotex or send real orders. It is demo/paper trading only.
- Signals are indicator heuristics, not calibrated probabilities or financial advice.

Twelve Data docs: https://twelvedata.com/docs
